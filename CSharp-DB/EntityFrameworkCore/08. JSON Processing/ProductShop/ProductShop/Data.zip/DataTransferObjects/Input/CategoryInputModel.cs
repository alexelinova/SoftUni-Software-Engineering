﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.DataTransferObjects.Input
{
    public class CategoryInputModel
    {
        public string Name { get; set; }
    }
}
