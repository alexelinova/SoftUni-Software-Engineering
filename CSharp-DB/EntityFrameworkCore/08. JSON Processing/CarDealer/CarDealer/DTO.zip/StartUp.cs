﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO.Import;
using CarDealer.Models;
using Castle.Core.Resource;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            CarDealerContext dbContext = new CarDealerContext();
            
            Mapper.Initialize(cfg => cfg.AddProfile(typeof(CarDealerProfile)));

            string suppliersAsJson = File.ReadAllText(@"../../../Datasets/suppliers.json");
            string partsAsJson = File.ReadAllText(@"../../../Datasets/parts.json");
            string carsAsJson = File.ReadAllText(@"../../../Datasets/cars.json");
            string customersAsJson = File.ReadAllText(@"../../../Datasets/customers.json");
            string salesAsJson = File.ReadAllText(@"../../../Datasets/sales.json");

            //ImportSuppliers(dbcontext, suppliersAsJson);
            //ImportParts(dbcontext, partsAsJson);
            //ImportCars(dbContext, carsAsJson);
            //ImportCustomers(dbContext, customersAsJson);
            Console.WriteLine(ImportSales(dbContext, salesAsJson));
            
        }

        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
           
            IEnumerable<ImportSupplierDto> supplierDto = JsonConvert
                .DeserializeObject<IEnumerable<ImportSupplierDto>>(inputJson);

            IEnumerable<Supplier> suppliers = Mapper.Map<IEnumerable<Supplier>>(supplierDto);

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count()}.";
        }

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            List<int> supplierId = context.Suppliers
                .Select(x => x.Id)
                .ToList();

            IEnumerable<ImportPartDto> partDto = JsonConvert
                .DeserializeObject<IEnumerable<ImportPartDto>>(inputJson);

            IEnumerable<Part> parts = Mapper.Map<IEnumerable<Part>>(partDto)
                .Where(p => supplierId.Contains(p.SupplierId))
                .ToList();

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count()}.";
        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            IEnumerable<ImportCarDto> carsDto = JsonConvert
                .DeserializeObject<IEnumerable<ImportCarDto>>(inputJson);

            foreach (var car in carsDto)
            {
                Car newCar = new Car
                {
                    Make = car.Make,
                    Model = car.Model,
                    TravelledDistance = car.TravelledDistance
                };

                foreach (var partId in car.PartsId.Distinct())
                {
                    newCar.PartCars.Add(new PartCar
                    {
                        PartId = partId
                    });
                }

                context.Cars.Add(newCar);
                context.SaveChanges();
            }

            return $"Successfully imported {carsDto.Count()}.";
        }

        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            IEnumerable<ImportCustomerDto> customersDto = JsonConvert
                .DeserializeObject<IEnumerable<ImportCustomerDto>>(inputJson);

            IEnumerable<Customer> customers = Mapper.Map<IEnumerable<Customer>>(customersDto);

            context.Customers.AddRange(customers);
            context.SaveChanges();

            return $"Successfully imported {customers.Count()}.";
        }

        public static string ImportSales(CarDealerContext context, string inputJson)
        {
            IEnumerable<ImportSaleDto> salesDto = JsonConvert.DeserializeObject<IEnumerable<ImportSaleDto>>(inputJson);

            IEnumerable<Sale> sales = Mapper.Map<IEnumerable<Sale>>(salesDto);

            context.Sales.AddRange(sales);
            context.SaveChanges();

            return $"Successfully imported {sales.Count()}.";
        }
    }
}