﻿namespace CarDealer.DTO.Import
{
    public class ImportSupplierDto
    {
        public string Name { get; set; }

        public bool isImporter { get; set; }
    }
}
