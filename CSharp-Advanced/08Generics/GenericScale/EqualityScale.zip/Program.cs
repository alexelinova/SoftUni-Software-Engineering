﻿using System;

namespace GenericScale
{
    public class Program
    {
        public static void Main(string[] args)
        {
            
        }
    }
}
