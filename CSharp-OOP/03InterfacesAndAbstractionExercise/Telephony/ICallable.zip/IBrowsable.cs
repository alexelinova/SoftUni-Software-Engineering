﻿
namespace Telephony
{
    public interface IBrowsable
    {
        string Browse(string URL);
    }
}
