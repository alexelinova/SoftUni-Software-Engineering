﻿using EasterRaces.Models.Drivers.Contracts;
using EasterRaces.Repositories.Contracts;
using EasterRaces.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;


namespace EasterRaces.Repositories.Entities
{
    public class DriverRepository : IRepository<IDriver>
    {
        private readonly List<IDriver> models;

        public DriverRepository()
        {
            this.models = new List<IDriver>();
        }

        public IDriver FirstOrDefault { get; internal set; }

        public void Add(IDriver model)
        {
           
            models.Add(model);
        }

        public IReadOnlyCollection<IDriver> GetAll()
        {
            return this.models.AsReadOnly();
        }

        public IDriver GetByName(string name)
        {
            IDriver driver = models.FirstOrDefault(m => m.Name == name);

            return driver;
        }

        public bool Remove(IDriver model)
        {
            return models.Remove(model);
        }
    }
}
