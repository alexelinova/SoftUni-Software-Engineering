﻿using EasterRaces.Models.Races.Contracts;
using EasterRaces.Repositories.Contracts;
using EasterRaces.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;


namespace EasterRaces.Repositories.Entities
{
    class RaceRepository : IRepository<IRace>
    {
        private readonly List<IRace> models;

        public RaceRepository()
        {
            models = new List<IRace>();
        }
        public void Add(IRace model)
        {
            models.Add(model);
        }

        public IReadOnlyCollection<IRace> GetAll()
        {
            return this.models.AsReadOnly();
        }

        public IRace GetByName(string name)
        {
            IRace race = models.FirstOrDefault(m => m.Name == name);

            return race;
        }

        public bool Remove(IRace model)
        {
            return models.Remove(model);
        }
    }
}
